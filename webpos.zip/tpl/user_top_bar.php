<!-- TOP BAR -->

	<div id="top-bar">
		
		<div class="page-full-width cf">

			<ul id="nav" class="fl">
	
				
			
			
				<li><a href="logout.php?logout=true" class="round button dark menu-logoff image-left">Log out </a></li>
				
			</ul> <!-- end nav -->

			
		</div> <!-- end full-width -->	
	
	</div> <!-- end top-bar -->