<?php

$config["database"] = "webpos"; 
$config["host"]= "localhost";
$config["username"]= "root"; 
$config["password"]= "";
?>